import UIKit

enum choices {
    case rock
    case paper
    case scissors
}
protocol GetChoice {
    func getchoice() -> choices
}
protocol PrintWinner {
    func printwinner()
}
class Player : GetChoice, PrintWinner {
    var name : String
    var choice : choices
    init(name : String, choice : choices) {
        self.name = name
        self.choice = choice
    }
    func getchoice() -> choices {
        return self.choice
    }
    func printwinner() {
        print("Winner is \(name)")
    }
}

var player1 = Player(name: "Alikhan", choice: .rock)
var player2 = Player(name: "Ayana", choice: .scissors)

var choice1 : choices = player1.getchoice()
var choice2 : choices = player2.getchoice()

if choice1 == .rock && choice2 == .scissors {
    player1.printwinner()
}
else if choice1 == .scissors && choice2 == .paper {
    player1.printwinner()
}
else if choice1 == .paper && choice2 == .rock {
    player1.printwinner()
}
else if choice1 == .scissors && choice2 == .rock {
    player2.printwinner()
}
else if choice1 == .paper && choice2 == .scissors {
    player2.printwinner()
}
else if choice1 == .rock && choice2 == .paper {
    player2.printwinner()
}
else {
    print("Draw")
}
